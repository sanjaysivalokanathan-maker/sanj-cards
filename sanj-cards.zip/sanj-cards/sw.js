/* Network-first service worker: always fresh when online,
   falls back to cache when offline. Bump CACHE on each release. */
const CACHE = 'sanjcards-v1';
const ASSETS = [
  './', './index.html', './styles.css?v=1', './manifest.webmanifest',
  './js/core.js?v=1', './js/guidelines.js?v=1', './js/hemo.js?v=1', './js/ref.js?v=1'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    fetch(e.request)
      .then(res => {
        const copy = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, copy)).catch(()=>{});
        return res;
      })
      .catch(() => caches.match(e.request).then(r => r || caches.match('./index.html')))
  );
});
