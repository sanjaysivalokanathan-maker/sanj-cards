/* ============================================================
   CARDS — core engine
   Handles: module registry, hash routing, search, rendering,
   and a small declarative calculator builder.
   Content modules call CARDS.register(...) to add themselves.
   You should rarely need to edit this file.
   ============================================================ */
(function () {
  const modules = [];        // registered topic modules
  const calcs = [];          // flat index of every calculator (for search)

  const CARDS = {
    /* A module = { id, title, icon, items: [...] }
       An item   = a calculator or a reference card. */
    register(mod) {
      modules.push(mod);
      (mod.items || []).forEach(it => {
        calcs.push({ modId: mod.id, modTitle: mod.title, ...it });
      });
    },

    start() {
      this._wireSearch();
      window.addEventListener('hashchange', () => this._route());
      this._route();
      this._renderNav();
    },

    /* ---------- routing ---------- */
    _route() {
      const hash = location.hash.replace(/^#\/?/, '');     // "" | "calc/map" | "mod/hemo"
      const app = document.getElementById('app');
      if (!hash) return this._home(app);

      const [kind, id] = hash.split('/');
      if (kind === 'calc') {
        const c = calcs.find(x => x.id === id);
        return c ? this._renderCalc(app, c) : this._home(app);
      }
      if (kind === 'mod') {
        const m = modules.find(x => x.id === id);
        return m ? this._renderModule(app, m) : this._home(app);
      }
      this._home(app);
    },

    /* ---------- home: list all modules ---------- */
    _home(app) {
      app.innerHTML = `
        <h1 class="page-title">Bedside Reference</h1>
        <p class="page-sub">Tap a section. Everything works offline.</p>
        <div class="grid">
          ${modules.map(m => `
            <a class="card-link" href="#/mod/${m.id}">
              <span class="card-icon">${m.icon || '•'}</span>
              <span class="card-title">${m.title}</span>
              <span class="card-meta">${(m.items||[]).length} items</span>
            </a>`).join('')}
        </div>`;
    },

    /* ---------- a single module: list its items ---------- */
    _renderModule(app, m) {
      app.innerHTML = `
        <a class="back" href="#/">‹ Home</a>
        <h1 class="page-title">${m.icon || ''} ${m.title}</h1>
        <div class="grid">
          ${m.items.map(it => `
            <a class="card-link" href="#/calc/${it.id}">
              <span class="card-title">${it.title}</span>
              ${it.subtitle ? `<span class="card-meta">${it.subtitle}</span>` : ''}
            </a>`).join('')}
        </div>`;
    },

    /* ---------- render one calculator or reference card ---------- */
    _renderCalc(app, c) {
      // Reference card (static content, no inputs)
      if (c.type === 'ref') {
        app.innerHTML = `
          <a class="back" href="#/mod/${c.modId}">‹ ${c.modTitle}</a>
          <h1 class="page-title">${c.title}</h1>
          <div class="refbody">${c.body}</div>`;
        return;
      }

      // Calculator (inputs -> compute -> result)
      app.innerHTML = `
        <a class="back" href="#/mod/${c.modId}">‹ ${c.modTitle}</a>
        <h1 class="page-title">${c.title}</h1>
        ${c.subtitle ? `<p class="page-sub">${c.subtitle}</p>` : ''}
        <div class="inputs">
          ${c.inputs.map(inp => this._inputHTML(inp)).join('')}
        </div>
        <div class="result" id="result"></div>
        ${c.note ? `<p class="note">${c.note}</p>` : ''}`;

      const recompute = () => {
        const vals = {};
        c.inputs.forEach(inp => {
          const el = document.getElementById('in_' + inp.key);
          vals[inp.key] = inp.options ? el.value : parseFloat(el.value);
        });
        const out = c.compute(vals);
        const res = document.getElementById('result');
        if (out == null || (typeof out.value === 'number' && isNaN(out.value))) {
          res.innerHTML = '<span class="result-empty">Enter values…</span>';
          return;
        }
        res.innerHTML = `
          <div class="result-value">${out.value}${out.unit ? ` <span class="result-unit">${out.unit}</span>` : ''}</div>
          ${out.interpretation ? `<div class="result-interp ${out.flag||''}">${out.interpretation}</div>` : ''}`;
      };

      c.inputs.forEach(inp => {
        const el = document.getElementById('in_' + inp.key);
        el.addEventListener('input', recompute);
        el.addEventListener('change', recompute);
      });
      recompute();
    },

    _inputHTML(inp) {
      if (inp.options) {
        return `<label class="field">
          <span class="field-label">${inp.label}</span>
          <select id="in_${inp.key}">
            ${inp.options.map(o => `<option value="${o.value}">${o.label}</option>`).join('')}
          </select></label>`;
      }
      return `<label class="field">
        <span class="field-label">${inp.label}${inp.unit ? ` <em>(${inp.unit})</em>` : ''}</span>
        <input type="number" inputmode="decimal" id="in_${inp.key}"
               ${inp.value != null ? `value="${inp.value}"` : ''}
               ${inp.step != null ? `step="${inp.step}"` : ''}
               placeholder="${inp.placeholder || ''}" /></label>`;
    },

    /* ---------- nav (back to home link in header) ---------- */
    _renderNav() { /* header brand already links home; reserved for future */ },

    /* ---------- search ---------- */
    _wireSearch() {
      const toggle = document.getElementById('searchToggle');
      const overlay = document.getElementById('searchOverlay');
      const input = document.getElementById('searchInput');
      const results = document.getElementById('searchResults');
      const close = document.getElementById('searchClose');
      if (!toggle) return;

      const open = () => { overlay.hidden = false; input.value = ''; results.innerHTML = ''; input.focus(); };
      const shut = () => { overlay.hidden = true; };
      toggle.addEventListener('click', open);
      close.addEventListener('click', shut);
      overlay.addEventListener('click', e => { if (e.target === overlay) shut(); });
      document.addEventListener('keydown', e => { if (e.key === 'Escape') shut(); });

      input.addEventListener('input', () => {
        const q = input.value.trim().toLowerCase();
        if (!q) { results.innerHTML = ''; return; }
        const hits = calcs.filter(c =>
          (c.title + ' ' + (c.subtitle||'') + ' ' + (c.keywords||'') + ' ' + c.modTitle)
            .toLowerCase().includes(q)).slice(0, 20);
        results.innerHTML = hits.length
          ? hits.map(c => `<a class="search-hit" href="#/calc/${c.id}" data-shut>
               <strong>${c.title}</strong><span>${c.modTitle}</span></a>`).join('')
          : '<p class="search-empty">No matches</p>';
        results.querySelectorAll('[data-shut]').forEach(a => a.addEventListener('click', shut));
      });
    }
  };

  window.CARDS = CARDS;
})();
