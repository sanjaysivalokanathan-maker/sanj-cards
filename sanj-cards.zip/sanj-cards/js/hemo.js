/* ============================================================
   Hemodynamics module
   To add a calculator: copy one of the objects in `items` and
   edit its inputs + compute(). The engine renders it automatically.
   ============================================================ */
CARDS.register({
  id: 'hemo',
  title: 'Hemodynamics',
  icon: '🫀',
  items: [
    {
      id: 'map',
      title: 'Mean Arterial Pressure',
      subtitle: 'MAP from SBP / DBP',
      keywords: 'map perfusion pressure blood',
      inputs: [
        { key: 'sbp', label: 'Systolic BP',  unit: 'mmHg', placeholder: '120' },
        { key: 'dbp', label: 'Diastolic BP', unit: 'mmHg', placeholder: '80' }
      ],
      compute({ sbp, dbp }) {
        if (isNaN(sbp) || isNaN(dbp)) return null;
        const map = (sbp + 2 * dbp) / 3;
        let flag = '', interp = '';
        if (map < 65)      { flag = 'bad';  interp = 'Below 65 — organ perfusion at risk.'; }
        else if (map > 110){ flag = 'warn'; interp = 'Elevated.'; }
        else               { flag = 'ok';   interp = 'Within usual target range.'; }
        return { value: map.toFixed(0), unit: 'mmHg', interpretation: interp, flag };
      },
      note: 'MAP = (SBP + 2·DBP) / 3. Common target ≥ 65 mmHg; individualize.'
    },
    {
      id: 'co-fick',
      title: 'Cardiac Output (Fick)',
      subtitle: 'Estimated VO₂ method',
      keywords: 'fick cardiac output co index ci',
      inputs: [
        { key: 'hb',   label: 'Hemoglobin',   unit: 'g/dL', placeholder: '13' },
        { key: 'sao2', label: 'Arterial O₂ sat',  unit: '%', placeholder: '98' },
        { key: 'svo2', label: 'Mixed venous O₂ sat', unit: '%', placeholder: '65' },
        { key: 'bsa',  label: 'BSA', unit: 'm²', placeholder: '1.9' }
      ],
      compute({ hb, sao2, svo2, bsa }) {
        if ([hb, sao2, svo2, bsa].some(isNaN)) return null;
        const vo2 = 125 * bsa;                       // assumed VO2
        const avDiff = 1.34 * hb * 10 * (sao2 - svo2) / 100; // mL O2 / L
        const co = vo2 / avDiff;                      // L/min
        const ci = co / bsa;
        let flag = ci < 2.2 ? 'bad' : (ci > 4 ? 'warn' : 'ok');
        return {
          value: co.toFixed(2), unit: 'L/min',
          interpretation: `Cardiac index ≈ ${ci.toFixed(2)} L/min/m² · uses assumed VO₂ 125·BSA.`,
          flag
        };
      },
      note: 'Assumed-Fick estimate. Measured VO₂ is more accurate when available.'
    }
  ]
});
