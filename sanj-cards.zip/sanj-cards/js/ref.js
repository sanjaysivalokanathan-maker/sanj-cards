/* ============================================================
   Reference module — static lookup cards (type: 'ref').
   Use this pattern for normal values, checklists, tables.
   ============================================================ */
CARDS.register({
  id: 'ref',
  title: 'Quick Reference',
  icon: '📋',
  items: [
    {
      id: 'echo-normals',
      type: 'ref',
      title: 'Echo Normal Values',
      subtitle: 'Common adult chamber measures',
      keywords: 'echo normals lvef la lv rv tapse dimensions',
      body: `
        <table class="ref-table">
          <tr><th>Measure</th><th>Normal range</th></tr>
          <tr><td>LVEF</td><td>52–72%</td></tr>
          <tr><td>LV end-diastolic diameter</td><td>4.2–5.8 cm</td></tr>
          <tr><td>LA diameter</td><td>2.7–4.0 cm</td></tr>
          <tr><td>TAPSE</td><td>≥ 1.7 cm</td></tr>
          <tr><td>IVC diameter</td><td>≤ 2.1 cm, &gt;50% collapse</td></tr>
        </table>
        <p class="ref-cite">Replace with your institution's reference ranges.</p>`
    },
    {
      id: 'swan-values',
      type: 'ref',
      title: 'Swan-Ganz Normals',
      subtitle: 'Right heart cath pressures',
      keywords: 'swan ganz pa wedge rap pcwp normal pressures',
      body: `
        <table class="ref-table">
          <tr><th>Site</th><th>Normal</th></tr>
          <tr><td>RA (mean)</td><td>2–6 mmHg</td></tr>
          <tr><td>RV</td><td>15–30 / 2–8 mmHg</td></tr>
          <tr><td>PA</td><td>15–30 / 8–15 mmHg</td></tr>
          <tr><td>PCWP</td><td>6–12 mmHg</td></tr>
          <tr><td>Cardiac index</td><td>2.5–4.0 L/min/m²</td></tr>
        </table>
        <p class="ref-cite">Verify against your lab's reference values.</p>`
    }
  ]
});
